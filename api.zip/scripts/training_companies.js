console.log("training_companies");

let container = document.querySelector('#search-apprenticeship-companies-container');
let filterButton = document.querySelector('#filter-search-table');
let filterReset = document.querySelector('#filter-reset');
let filterWhereInput = document.querySelector('#filter-where-input');
let filterTermInput = document.querySelector("#filter-term-input");

// 
window.search_page = 1;
window.filter_city = '';
window.filter_term = '';

let search_endpoint = 'api/compaines_filter.php';

function getSearchEndpoint() {
  return `${search_endpoint}?page=${window.search_page}&city=${window.filter_city}&term=${window.filter_term}`;
}


fetch(getSearchEndpoint()).then(response => response.json()).then(response => {
  container.innerHTML = buildTable(response.cols, response.result, response.pages)
})


window.rebuildTable = function () {
  fetch(getSearchEndpoint()).then(response => response.json()).then(response => {
    container.innerHTML = '';
    container.innerHTML = buildTable(response.cols, response.result, response.pages)
  })
}


filterReset.onclick = function () {
  filterWhereInput.value = '';
  filterTermInput.value = '';
  fetch(getSearchEndpoint()).then(response => response.json()).then(response => {
    container.innerHTML = buildTable(response.cols, response.result, response.pages)
  })
  filterButton.click()
}

filterButton.onclick = function () {
  window.filter_city = filterWhereInput.value;
  window.filter_term = filterTermInput.value;
  window.search_page = 1;
  fetch(getSearchEndpoint()).then(response => response.json()).then(response => {
    container.innerHTML = buildTable(response.cols, response.result, response.pages)
  })
}

function buildTable(cols = [], data = [], pages = 0,) {
  let table = `<table class="table table-bordered text-start">`;
  // head
  table += '<thead>';
  table += '<tr>';
  cols.forEach(e => {
    table += `<th>${e}</th>`
  });
  table += '</tr>';
  table += '</thead>';
  // body
  table += '<tbody>';
  data.forEach(e => {
    table += '<tr>';
    table += `<td>${e.company_name}</td>`
    table += `<td>${e.post_title}</td>`
    table += `<td>${e.post_salary}</td>`
    table += `<td>${e.post_skill}</td>`
    table += `<td>${e.post_city}</td>`
    table += '</tr>';
  });
  table += '</tbody>';
  // close table 
  table += '</table>'

  // start pages 
  let pages_numbers = `
  <div class="btn-toolbar mb-3" role="toolbar" aria-label="Toolbar with button groups">
  <div class="btn-group me-2" role="group" aria-label="First group">
  `;
  for (let index = 0; index < pages; index++) {
    pages_numbers += `<button 
                          type="button" 
                          class="btn btn-outline-secondary ${(index + 1) == window.search_page ? ' active ' : ''}" 
                          onclick='window.search_page=${(index + 1)};window.rebuildTable()'
                          >
                          ${index + 1}
                       </button>`;
  }
  // close pages number 
  pages_numbers += '</div></div>'
  table += pages_numbers;
  return table;
}