<?php

print "api";