<?php
$username = "root";
$password = "";
$dbname = "tenderfu_there";
$host = 'localhost';

$con = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);