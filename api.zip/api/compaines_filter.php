<?php

require_once(__DIR__ . '/dbcon.php');

$perPage = 5;
// Calculate Total pages
$countquery = "SELECT count(*) FROM posts as P inner JOIN company as C on C.id = P.company_id";
if (isset($_GET['city']) && !empty($_GET['city']))
  $countquery .= " WHERE P.city LIKE '%{$_GET['city']}%'  ";

if (isset($_GET['term']) && !empty($_GET['term']))
  $countquery .= " WHERE C.name LIKE '%{$_GET['term']}%'  ";

$stmt = $con->query($countquery);
$total_results = $stmt->fetchColumn();
$total_pages = ceil($total_results / $perPage);
// Current page
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$starting_limit = ($page - 1) * $perPage;
// Query to fetch 
$query = "SELECT C.name company_name, P.title post_title , P.salary post_salary, P.skill post_skill, P.city post_city FROM posts as P inner JOIN company as C on C.id = P.company_id";
if (isset($_GET['city']) && !empty($_GET['city']))
  $query .= " WHERE P.city LIKE '%{$_GET['city']}%'  ";

if (isset($_GET['term']) && !empty($_GET['term']))
  $query .= " WHERE C.name LIKE '%{$_GET['term']}%'  ";
$query .= " LIMIT $starting_limit,$perPage";
// Fetch all users for current page
$result = $con->query($query)->fetchAll(\PDO::FETCH_ASSOC);
// order is important
$cols = ['Company Name', 'Title', 'Salary', 'Skill', 'City'];
header('content-type: application/json');
print_r(json_encode(['result' => $result, 'pages' => $total_pages, 'cols' => $cols]));